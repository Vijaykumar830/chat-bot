from django import forms
from django.contrib.auth.models import User
from .models import UserProfile, Loan

class UserRegistrationForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput, label="Password")
    confirm_password = forms.CharField(widget=forms.PasswordInput, label="Confirm Password")

    class Meta:
        model = User
        fields = ['username', 'email', 'password']

    def clean(self):
        cleaned_data = super().clean()
        password = cleaned_data.get('password')
        confirm_password = cleaned_data.get('confirm_password')

        if password != confirm_password:
            raise forms.ValidationError("Passwords do not match.")
        return cleaned_data

class UserProfileForm(forms.ModelForm):
    ACCOUNT_TYPE_CHOICES = [
        ('savings', 'Savings Account'),
        ('current', 'Current Account'),
        ('fixed', 'Fixed Deposit Account'),
    ]

    account_type = forms.ChoiceField(choices=ACCOUNT_TYPE_CHOICES, label="Account Type")
    address = forms.CharField(widget=forms.Textarea(attrs={'rows': 3}), label="Address")
    phone_number = forms.CharField(max_length=15, label="Phone Number")
    account_number = forms.CharField(max_length=20, label="Account Number", required=False)  # Not required now

    class Meta:
        model = UserProfile
        fields = ['account_type', 'address', 'phone_number', 'account_number']

    def clean_phone_number(self):
        phone_number = self.cleaned_data.get('phone_number')
        if not phone_number.isdigit():
            raise forms.ValidationError("Phone number must contain only digits.")
        if len(phone_number) < 10:
            raise forms.ValidationError("Phone number must be at least 10 digits long.")
        return phone_number

    def clean_account_number(self):
        account_number = self.cleaned_data.get('account_number')
        if account_number and UserProfile.objects.filter(account_number=account_number).exists():
            raise forms.ValidationError("Account number already exists.")
        return account_number


class DepositForm(forms.Form):
    amount = forms.DecimalField(max_digits=10, decimal_places=2, min_value=0.01, label="Amount")

    def clean_amount(self):
        amount = self.cleaned_data.get('amount')
        if amount <= 0:
            raise forms.ValidationError("Deposit amount must be greater than zero.")
        return amount

class TransferForm(forms.Form):
    recipient_account_number = forms.CharField(max_length=20, label="Recipient's Account Number")
    amount = forms.DecimalField(max_digits=10, decimal_places=2, min_value=0.01, label="Amount to Transfer")
    description = forms.CharField(widget=forms.Textarea(attrs={'rows': 3}), label="Description")

    def clean_amount(self):
        amount = self.cleaned_data.get('amount')
        if amount <= 0:
            raise forms.ValidationError("Transfer amount must be greater than zero.")
        return amount

    def clean_recipient_account_number(self):
        recipient_account_number = self.cleaned_data.get('recipient_account_number')
        if not UserProfile.objects.filter(account_number=recipient_account_number).exists():
            raise forms.ValidationError("Recipient account number does not exist.")
        return recipient_account_number

class LoanApplicationForm(forms.ModelForm):
    class Meta:
        model = Loan
        fields = ['loan_amount', 'interest_rate', 'duration_in_months']

    def clean_loan_amount(self):
        loan_amount = self.cleaned_data.get('loan_amount')
        if loan_amount <= 0:
            raise forms.ValidationError("Loan amount must be greater than zero.")
        return loan_amount

    def clean_interest_rate(self):
        interest_rate = self.cleaned_data.get('interest_rate')
        if interest_rate <= 0 or interest_rate > 100:
            raise forms.ValidationError("Interest rate must be between 0 and 100 percent.")
        return interest_rate

    def clean_duration_in_months(self):
        duration_in_months = self.cleaned_data.get('duration_in_months')
        if duration_in_months <= 0:
            raise forms.ValidationError("Duration in months must be greater than zero.")
        return duration_in_months
