from django.db import models
from django.contrib.auth.models import User
from decimal import Decimal
from dateutil.relativedelta import relativedelta

class UserProfile(models.Model):
    ACCOUNT_TYPE_CHOICES = [
        ('savings', 'Savings Account'),
        ('current', 'Current Account'),
        ('fixed', 'Fixed Deposit Account'),
    ]
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    account_type = models.CharField(max_length=20, choices=ACCOUNT_TYPE_CHOICES, default='savings')
    address = models.TextField()
    phone_number = models.CharField(max_length=15)
    account_number = models.CharField(max_length=20, unique=True)
    balance = models.DecimalField(max_digits=15, decimal_places=2, default=Decimal('0.00'))

    def calculate_balance(self):
        transactions = self.transactions.all()  # Use related_name defined in Transaction model
        credits = transactions.filter(transaction_type='credit').aggregate(total=models.Sum('amount'))['total'] or Decimal('0.00')
        debits = transactions.filter(transaction_type='debit').aggregate(total=models.Sum('amount'))['total'] or Decimal('0.00')
        transfers_out = transactions.filter(transaction_type='transfer').aggregate(total=models.Sum('amount'))['total'] or Decimal('0.00')
        loans = transactions.filter(transaction_type='loan').aggregate(total=models.Sum('amount'))['total'] or Decimal('0.00')
        transfers_in = Transaction.objects.filter(recipient_account_number=self.account_number, transaction_type='transfer').aggregate(total=models.Sum('amount'))['total'] or Decimal('0.00')

        self.balance = credits + transfers_in - debits - transfers_out - loans
        self.save()

    def __str__(self):
        return self.user.username

class Bank(models.Model):
    total_balance = models.DecimalField(max_digits=15, decimal_places=2, default=Decimal('0.00'))

    def update_balance(self):
        # Calculate total balance from all users and add to the bank balance
        users_total_balance = UserProfile.objects.aggregate(total=models.Sum('balance'))['total'] or Decimal('0.00')
        self.total_balance = users_total_balance
        self.save()

    @classmethod
    def get_bank(cls):
        bank, created = cls.objects.get_or_create(id=1)
        return bank

class Transaction(models.Model):
    TRANSACTION_TYPE_CHOICES = [
        ('credit', 'Credit'),
        ('debit', 'Debit'),
        ('transfer', 'Transfer'),
        ('loan', 'Loan'),
        ('received', 'Received'),  # Add 'received' type
    ]
    user_profile = models.ForeignKey(UserProfile, on_delete=models.CASCADE, related_name='transactions')
    recipient_account_number = models.CharField(max_length=20, blank=True, null=True)  # For transfers
    transaction_type = models.CharField(max_length=10, choices=TRANSACTION_TYPE_CHOICES)
    amount = models.DecimalField(max_digits=15, decimal_places=2)
    date = models.DateTimeField(auto_now_add=True)
    description = models.TextField()

    def save(self, *args, **kwargs):
        # Handle deposits, withdrawals, and transfers
        if self.transaction_type in ['debit', 'loan', 'transfer']:
            if self.user_profile.balance < self.amount:
                raise ValueError("Insufficient balance for the transaction.")

        if self.transaction_type == 'transfer':
            recipient = UserProfile.objects.get(account_number=self.recipient_account_number)
            recipient.balance += self.amount
            recipient.save()

            # Create a corresponding 'received' transaction for the recipient
            Transaction.objects.create(
                user_profile=recipient,
                recipient_account_number=self.user_profile.account_number,
                transaction_type='received',
                amount=self.amount,
                description=f'Received from {self.user_profile.account_number}'
            )

        # Adjust user's balance based on the transaction type
        if self.transaction_type in ['debit', 'loan', 'transfer']:
            self.user_profile.balance -= self.amount
        elif self.transaction_type == 'credit':
            self.user_profile.balance += self.amount

        self.user_profile.save()

        # Update bank's total balance after the transaction
        Bank.get_bank().update_balance()

        # Create a ledger entry for this transaction
        Ledger.objects.create(user=self.user_profile, transaction=self, balance_after_transaction=self.user_profile.balance)

        super().save(*args, **kwargs)


class Loan(models.Model):
    user = models.ForeignKey(UserProfile, on_delete=models.CASCADE)
    loan_amount = models.DecimalField(max_digits=15, decimal_places=2)
    interest_rate = models.DecimalField(max_digits=5, decimal_places=2)
    duration_in_months = models.IntegerField()
    start_date = models.DateField(auto_now_add=True)
    end_date = models.DateField(null=True, blank=True)
    is_paid_off = models.BooleanField(default=False)

    def calculate_total_repayment(self):
        # Simple interest formula: A = P(1 + rt)
        principal = self.loan_amount
        rate = self.interest_rate / Decimal('100')
        time = self.duration_in_months / Decimal('12')
        return principal * (1 + rate * time)

    def save(self, *args, **kwargs):
        if not self.end_date:
            self.end_date = self.start_date + relativedelta(months=self.duration_in_months)
        super().save(*args, **kwargs)

class Ledger(models.Model):
    user = models.ForeignKey(UserProfile, on_delete=models.CASCADE)
    transaction = models.ForeignKey(Transaction, on_delete=models.CASCADE)
    balance_after_transaction = models.DecimalField(max_digits=15, decimal_places=2)
    date = models.DateTimeField(auto_now_add=True)

    def save(self, *args, **kwargs):
        # Ensure balance after transaction is correct before saving
        self.balance_after_transaction = self.user.balance
        super().save(*args, **kwargs)
