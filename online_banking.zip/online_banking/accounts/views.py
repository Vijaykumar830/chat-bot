from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.forms import AuthenticationForm
from .forms import UserRegistrationForm, UserProfileForm, TransferForm
from .models import UserProfile, Bank
from django.contrib.auth.decorators import login_required
from django.db.models import Sum
import random
from django.contrib import messages  # For showing alert messages
from transactions.models import Transaction


def register(request):
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        profile_form = UserProfileForm(request.POST)
        if form.is_valid() and profile_form.is_valid():
            user = form.save(commit=False)
            user.set_password(form.cleaned_data['password'])
            user.save()
            profile = profile_form.save(commit=False)
            profile.user = user
            profile.account_number = generate_account_number()
            profile.save()
            login(request, user)
            return redirect('profile')
    else:
        form = UserRegistrationForm()
        profile_form = UserProfileForm()
    return render(request, 'accounts/register.html', {'form': form, 'profile_form': profile_form})


@login_required
def admin_dashboard(request):
    # Get the total number of users
    total_users = UserProfile.objects.count()
    
    # Get the total number of transactions
    total_transactions = Transaction.objects.count()
    
    # Calculate the total balance
    total_balance = sum(user.balance for user in UserProfile.objects.all())
    
    # Render the admin_dashboard.html template with the retrieved data
    return render(request, 'admin_panel/admin_dashboard.html', {
        'total_users': total_users,
        'total_transactions': total_transactions,
        'total_balance': total_balance,
    })


def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                # Check if the user is staff
                if user.is_staff:
                    return redirect('admin_dashboard')
                else:
                    return redirect('profile')
    else:
        form = AuthenticationForm()
    return render(request, 'accounts/login.html', {'form': form})


@login_required
def profile(request):
    profile = get_object_or_404(UserProfile, user=request.user)
    bank = Bank.get_bank()
    return render(request, 'accounts/profile.html', {'profile': profile, 'total_balance': bank.total_balance})


def generate_account_number():
    return str(random.randint(1000000000, 9999999999))


@login_required
def transfer(request):
    if request.method == 'POST':
        form = TransferForm(request.POST)
        if form.is_valid():
            recipient_account_number = form.cleaned_data['recipient_account_number']
            amount = form.cleaned_data['amount']

            try:
                sender_profile = get_object_or_404(UserProfile, user=request.user)
                recipient_profile = get_object_or_404(UserProfile, account_number=recipient_account_number)

                if sender_profile.balance >= amount:
                    # Deduct from sender
                    sender_profile.balance -= amount
                    sender_profile.save()

                    # Add to recipient
                    recipient_profile.balance += amount
                    recipient_profile.save()

                    # Record the transaction (optional)
                    Transaction.objects.create(
                        sender=sender_profile,
                        recipient=recipient_profile,
                        amount=amount,
                        transaction_type='transfer'
                    )

                    # Show a success message and redirect
                    messages.success(request, "Transfer successful!")
                    return redirect('transaction_success')

                else:
                    form.add_error('amount', 'Insufficient funds')
            except UserProfile.DoesNotExist:
                form.add_error('recipient_account_number', 'Invalid account number')

    else:
        form = TransferForm()

    return render(request, 'transactions/transfer.html', {'form': form})


@login_required
def transaction_success(request):
    return render(request, 'transactions/transaction_success.html')


@login_required
def logout_view(request):
    # Log out the current user
    logout(request)
    # Redirect to the login page
    return redirect('login')
