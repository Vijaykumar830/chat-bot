from django import forms

class DepositForm(forms.Form):
    amount = forms.DecimalField(decimal_places=2, max_digits=10, label="Amount to Deposit")
