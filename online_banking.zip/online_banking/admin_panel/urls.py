from django.urls import path
from . import views

urlpatterns = [
    # path('deposit/', views.admin_deposit, name='admin_deposit'),
    path('dashboard/', views.admin_dashboard, name='admin_dashboard'),
    path('users/', views.user_list, name='user_list'),
    path('logout/', views.logout_view, name='logout'),
    path('transactions/', views.transaction_overview, name='transaction_overview'),
    path('admin_panel/users/<int:user_id>/', views.admin_user_detail, name='admin_user_detail'),
    path('admin_panel/users/delete/<int:user_id>/', views.admin_delete_user, name='admin_delete_user'),


]
