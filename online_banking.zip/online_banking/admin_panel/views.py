from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .forms import DepositForm  # Ensure this form is defined
from accounts.models import UserProfile, Bank
from transactions.models import Transaction
from django.shortcuts import render, get_object_or_404
from django.contrib.sessions.models import Session
from django.contrib.auth.models import User
from django.utils import timezone
from django.contrib.auth import logout

@login_required
def admin_deposit(request):
    if request.method == 'POST':
        form = DepositForm(request.POST)
        if form.is_valid():
            amount = form.cleaned_data['amount']

            # Retrieve the bank instance and update the total balance
            bank = Bank.objects.first()  # Assuming a single Bank instance exists
            bank.total_balance += amount
            bank.save()

            messages.success(request, "Deposit successful!")
            return redirect('admin_dashboard')
    else:
        form = DepositForm()

    return render(request, 'admin_panel/admin_deposit.html', {'form': form})

@login_required
def admin_dashboard(request):
    # Retrieve the latest logs
    try:
        with open('django_debug.log', 'r') as log_file:
            logs = log_file.readlines()[-100:]  # Get the last 100 lines
    except FileNotFoundError:
        logs = ["Log file not found."]

    # Retrieve active users
    sessions = Session.objects.filter(expire_date__gte=timezone.now())
    uid_list = [data.get('_auth_user_id', None) for session in sessions for data in [session.get_decoded()]]
    users = User.objects.filter(id__in=uid_list)

    # Calculate dashboard metrics
    total_users = User.objects.count()
    total_transactions = Transaction.objects.count()
    total_balance = sum(user_profile.balance for user_profile in UserProfile.objects.all()) if UserProfile.objects.exists() else 0

    return render(request, 'admin_panel/admin_dashboard.html', {
        'logs': logs,
        'users': users,
        'total_users': total_users,
        'total_transactions': total_transactions,
        'total_balance': total_balance,
    })

@login_required
def user_list(request):
    users = UserProfile.objects.select_related('user').all()  # Optimize query with select_related
    return render(request, 'admin_panel/user_list.html', {'users': users})

@login_required
def transaction_overview(request):
    transactions = Transaction.objects.select_related('user_profile').all()
    return render(request, 'admin_panel/transaction_overview.html', {'transactions': transactions})

@login_required
def user_profile_overview(request):
    user_profiles = UserProfile.objects.select_related('user').all()
    return render(request, 'admin_panel/user_profile_overview.html', {'user_profiles': user_profiles})

@login_required
def admin_user_detail(request, user_id):
    user_profile = get_object_or_404(UserProfile, id=user_id)
    return render(request, 'admin_panel/admin_user_detail.html', {'user_profile': user_profile})

@login_required
def admin_delete_user(request, user_id):
    user_profile = get_object_or_404(UserProfile, id=user_id)
    user_profile.delete()
    messages.success(request, f"User {user_profile.user.username} deleted successfully.")
    return redirect('user_list')

@login_required
def view_logs(request):
    with open('django_debug.log', 'r') as log_file:
        logs = log_file.readlines()[-100:]  # Get the last 100 lines
    return render(request, 'admin_panel/view_logs.html', {'logs': logs})

@login_required
def active_users(request):
    sessions = Session.objects.filter(expire_date__gte=timezone.now())
    uid_list = []
    for session in sessions:
        data = session.get_decoded()
        uid_list.append(data.get('_auth_user_id', None))

    users = User.objects.filter(id__in=uid_list)
    return render(request, 'admin_panel/active_users.html', {'users': users})

@login_required
def logout_view(request):
    # Log out the current user
    logout(request)
    # Redirect to the login page
    return redirect('login')
