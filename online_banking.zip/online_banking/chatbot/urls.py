from django.urls import path
from . import views

urlpatterns = [
    path('', views.chatbot, name='chatbot'),  # Main chatbot view
    path('logout/', views.custom_logout, name='logout'),
    path('leave/', views.leave_chatbot, name='leave_chatbot'),  # Leave the chatbot
]
