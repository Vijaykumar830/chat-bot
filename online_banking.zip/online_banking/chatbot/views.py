import json
import os
from decimal import Decimal
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_protect
from django.contrib.auth.decorators import login_required
from django.contrib.auth import logout
from django.shortcuts import render
from transactions.models import Transaction
from accounts.models import UserProfile
from transformers import pipeline  # Hugging Face for NLP
import random
import re  # For math expression evaluation

# Load NLP models (using Hugging Face pipeline)
nlp_model = pipeline("text-generation", model="gpt2")  # Or use a dialogue-based model like 'DialoGPT'

# Pre-defined conversational responses
small_talk_responses = {
    "hi": ["Hello! 😊", "Hey! How can I assist you today?", "Hi! 👋 What can I do for you?"],
    "how are you": ["I'm just a bot, but I'm feeling awesome! How about you?", "I'm great! What can I help with today? 😊"],
    "bye": ["Goodbye! Take care! 👋", "See you next time! 😊", "Have a great day!"],
    "thanks": ["You're welcome! 😊", "Anytime! Glad I could help!"],
    "joke": ["Why don't programmers like nature? It has too many bugs. 😄", "Why did the computer go to the doctor? It had a virus! 🦠"],
    "greetings": ["Hey! How can I help today?", "Hi! Need something? 😊", "Hello! What's up?"],
    "weather": ["The weather is looking beautiful today! ☀️", "It's a bit chilly outside, make sure to bundle up! ❄️", "Looks like it might rain later, don't forget your umbrella! ☔"],
    "time": ["It's currently [current time]. 😊"],
    "date": ["Today is [current date]. 😊"],
    "what can you do": ["I can help you with a variety of tasks, such as providing information, completing tasks, or simply having a conversation. What would you like to do today?"],
    "who are you": ["I'm a large language model, also known as a conversational AI or chatbot. I'm here to help you with whatever you need."],
    "tell me a story": ["Once upon a time, in a land far away...", "A long time ago, in a galaxy far, far away..."]
}

# Keeping conversation context
conversation_context = {}

@login_required
def chatbot(request):
    if request.method == 'GET':
        request.session['on_chatbot_page'] = True
        return render(request, 'chatbot/chatbot.html')

    if request.method == 'POST':
        if not request.session.get('on_chatbot_page', False):
            return JsonResponse({'reply': "Chatbot is only active on the chatbot page."}, status=403)

        try:
            data = json.loads(request.body)
            message = data.get('message', '').lower()
            user_profile = UserProfile.objects.get(user=request.user)

            # Check for small talk responses
            response = handle_small_talk(message)
            if not response:
                # Handle other chat messages
                response = handle_chat_message(message, user_profile, request)

            return JsonResponse({'reply': response}, status=200)

        except json.JSONDecodeError:
            return JsonResponse({'reply': "Invalid JSON received."}, status=400)
        except UserProfile.DoesNotExist:
            return JsonResponse({'reply': "User profile not found."}, status=404)
        except Exception as e:
            return JsonResponse({'reply': f"An error occurred: {str(e)}"}, status=500)

    return JsonResponse({'reply': "Invalid request method."}, status=405)

@login_required
@csrf_protect
def leave_chatbot(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        if data.get('leave_chatbot', False):
            request.session['on_chatbot_page'] = False
            return JsonResponse({'status': 'success'}, status=200)

    return JsonResponse({'status': 'invalid request'}, status=400)

# Small talk handler
def handle_small_talk(message):
    for keyword, responses in small_talk_responses.items():
        if keyword in message:
            return random.choice(responses)
    return None

def handle_chat_message(message, user_profile, request):
    # Handle math problems
    if is_math_problem(message):
        return handle_math_problem(message)

    # Handle balance-related queries
    if 'balance' in message:
        return f"Your current balance is {user_profile.balance}. Let me know if you need anything else! 😊"

    # Handle withdrawal requests
    if 'withdraw' in message:
        return handle_withdrawal(message, user_profile)

    # Handle transfer requests
    if 'transfer' in message:
        return handle_transfer(message, user_profile)

    # Profile details
    if 'profile' in message or 'name' in message:
        return get_profile_info(user_profile)

    # Generate human-like response using NLP
    response = generate_nlp_response(message, request)
    if response:
        return response

    # Default response
    return "I'm not sure about that, but feel free to ask me anything else! 😊"

# Function to handle math problems
def is_math_problem(message):
    return re.match(r'[\d+\-*/().]+', message) is not None

def handle_math_problem(message):
    try:
        result = eval(message)
        return f"The result is {result}. That was fun! 😃"
    except Exception as e:
        return f"Oops, I couldn't calculate that. Mind checking the math? 🤔"

# Generate human-like response using NLP
def generate_nlp_response(message, request):
    try:
        if request.user.id not in conversation_context:
            conversation_context[request.user.id] = []

        conversation_context[request.user.id].append(message)

        response = nlp_model(message, max_length=50, do_sample=True, temperature=0.7)[0]['generated_text']
        conversation_context[request.user.id].append(response)
        return response
    except Exception as e:
        return f"An error occurred while generating a response: {str(e)}"

def handle_withdrawal(message, user_profile):
    try:
        amount = extract_amount_from_message(message)
        if amount is None:
            return "I couldn't find the amount. Could you tell me how much you'd like to withdraw?"

        if amount <= user_profile.balance:
            user_profile.balance -= amount
            user_profile.save()

            Transaction.objects.create(
                user_profile=user_profile,
                transaction_type='Withdrawal',
                amount=amount,
                details=f"Withdrawn from account {user_profile.account_number}"
            )
            return f"Withdrawal of {amount} was successful! Your new balance is {user_profile.balance}. 😊"
        else:
            return "It looks like you don't have enough funds for that. 😕"

    except Exception as e:
        return f"An error occurred: {str(e)}"

def handle_transfer(message, user_profile):
    try:
        amount, recipient_account_number = extract_transfer_details(message)
        if amount is None or recipient_account_number is None:
            return "I couldn't find the recipient's account or amount. Could you clarify the details?"

        recipient_profile = UserProfile.objects.get(account_number=recipient_account_number)

        if user_profile.balance >= amount:
            perform_transfer(user_profile, recipient_profile, amount)
            return f"Transfer of {amount} to account {recipient_account_number} was successful! Your new balance is {user_profile.balance}. 👍"
        else:
            return "It looks like you don't have enough funds for that transfer. 😕"

    except UserProfile.DoesNotExist:
        return "I couldn't find that recipient's account number. Could you double-check it?"
    except Exception as e:
        return f"An error occurred: {str(e)}"

def perform_transfer(user_profile, recipient_profile, amount):
    user_profile.balance -= amount
    user_profile.save()

    recipient_profile.balance += amount
    recipient_profile.save()

    Transaction.objects.create(
        user_profile=user_profile,
        transaction_type='transfer',
        amount=amount,
        recipient_account_number=recipient_profile.account_number,
        details=f"Transferred to account {recipient_profile.account_number}"
    )

    Transaction.objects.create(
        user_profile=recipient_profile,
        transaction_type='received',
        amount=amount,
        recipient_account_number=user_profile.account_number,
        details=f"Received from account {user_profile.account_number}"
    )

def extract_amount_from_message(message):
    words = message.split()
    try:
        return Decimal([word for word in words if word.replace('.', '', 1).isdigit()][0])
    except (IndexError, ValueError):
        return None

def extract_transfer_details(message):
    parts = message.split()
    try:
        amount = Decimal([word for word in parts if word.replace('.', '', 1).isdigit()][0])
        recipient_account_number = [word for word in parts if word.isdigit() and word != str(int(amount))][0]
        return amount, recipient_account_number
    except (IndexError, ValueError):
        return None, None

@login_required
def transaction_history(request):
    user_profile = UserProfile.objects.get(user=request.user)
    transactions = Transaction.objects.filter(user_profile=user_profile).order_by('-timestamp')
    balance = user_profile.balance  # Get the user's current balance
    return render(request, 'transactions/transaction_history.html', {'transactions': transactions, 'balance': balance})

def get_profile_info(user_profile):
    return (f"Here are your profile details:\n"
            f"Name: {user_profile.user.username}\n"
            f"Account Number: {user_profile.account_number}\n"
            f"Balance: {user_profile.balance}\n")

@login_required
def custom_logout(request):
    logout(request)
    return JsonResponse({'message': 'You have been logged out.'})
