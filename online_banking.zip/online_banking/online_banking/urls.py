from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('accounts.urls')),  # Routes to the accounts app
    path('transactions/', include('transactions.urls')),  # Routes to the transactions app
    path('chatbot/', include('chatbot.urls')),  # Routes to the chatbot app
    path('admin_panel/', include('admin_panel.urls')),  # Routes to the admin_panel app
]
