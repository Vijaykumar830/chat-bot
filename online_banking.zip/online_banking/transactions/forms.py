from django import forms
from .models import Transaction

class DepositForm(forms.ModelForm):
    class Meta:
        model = Transaction
        fields = ['amount']
        labels = {
            'amount': 'Deposit Amount',
        }

class WithdrawForm(forms.ModelForm):
    class Meta:
        model = Transaction
        fields = ['amount']
        labels = {
            'amount': 'Withdrawal Amount',
        }

class TransferForm(forms.Form):
    recipient_account_number = forms.CharField(max_length=20, label="Recipient's Account Number")
    amount = forms.DecimalField(max_digits=10, decimal_places=2, min_value=0, label="Amount to Transfer")
