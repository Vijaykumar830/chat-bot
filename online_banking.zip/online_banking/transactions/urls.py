from django.urls import path
from . import views

urlpatterns = [
    path('deposit/', views.deposit, name='deposit'),
    path('withdraw/', views.withdraw, name='withdraw'),
    path('transfer/', views.transfer, name='transfer'),
    path('history/', views.transaction_history, name='transaction_history'),
    path('transaction-success/', views.transaction_success, name='transaction_success'),

]
