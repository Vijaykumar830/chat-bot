from django.shortcuts import render, redirect
from .forms import DepositForm, WithdrawForm, TransferForm
from .models import Transaction
from accounts.models import UserProfile, Bank
from django.contrib.auth.decorators import login_required
from django.contrib.auth import logout
from django.contrib import messages

@login_required
def deposit(request):
    if request.method == 'POST':
        form = DepositForm(request.POST)
        if form.is_valid():
            transaction = form.save(commit=False)
            transaction.user_profile = UserProfile.objects.get(user=request.user)
            transaction.transaction_type = 'credit'  # Use lowercase for consistency
            transaction.details = f"Deposited into account {transaction.user_profile.account_number}"
            transaction.save()

            # Update user's balance
            profile = transaction.user_profile
            profile.balance += transaction.amount
            profile.save()

            # Update bank's total balance
            bank = Bank.get_bank()
            bank.total_balance += transaction.amount
            bank.save()

            messages.success(request, "Deposit successful!")
            return redirect('transaction_history')
    else:
        form = DepositForm()

    return render(request, 'transactions/deposit.html', {'form': form})

@login_required
def withdraw(request):
    if request.method == 'POST':
        form = WithdrawForm(request.POST)
        if form.is_valid():
            transaction = form.save(commit=False)
            transaction.user_profile = UserProfile.objects.get(user=request.user)
            if transaction.amount <= transaction.user_profile.balance:
                transaction.transaction_type = 'debit'  # Use lowercase for consistency
                transaction.details = f"Withdrawn from account {transaction.user_profile.account_number}"
                transaction.save()

                # Update user's balance
                profile = transaction.user_profile
                profile.balance -= transaction.amount
                profile.save()

                # Update bank's total balance
                bank = Bank.get_bank()
                bank.total_balance -= transaction.amount
                bank.save()

                messages.success(request, "Withdrawal successful!")
                return redirect('transaction_history')
            else:
                form.add_error(None, "Insufficient balance.")
    else:
        form = WithdrawForm()

    return render(request, 'transactions/withdraw.html', {'form': form})

@login_required
def transfer(request):
    if request.method == 'POST':
        form = TransferForm(request.POST)
        if form.is_valid():
            recipient_account_number = form.cleaned_data['recipient_account_number']
            amount = form.cleaned_data['amount']

            try:
                sender_profile = UserProfile.objects.get(user=request.user)
                recipient_profile = UserProfile.objects.get(account_number=recipient_account_number)

                if sender_profile.balance >= amount:
                    # Deduct from sender
                    sender_profile.balance -= amount
                    sender_profile.save()

                    # Add to recipient
                    recipient_profile.balance += amount
                    recipient_profile.save()

                    # Create transaction record for sender
                    Transaction.objects.create(
                        user_profile=sender_profile,
                        transaction_type='transfer',  # Use lowercase for consistency
                        amount=amount,
                        recipient_account_number=recipient_account_number,
                        details=f"Transferred to account {recipient_account_number}"
                    )

                    # Create transaction record for recipient
                    Transaction.objects.create(
                        user_profile=recipient_profile,
                        transaction_type='received',  # Use lowercase for consistency
                        amount=amount,
                        recipient_account_number=sender_profile.account_number,
                        details=f"Received from account {sender_profile.account_number}"
                    )

                    messages.success(request, "Transfer successful!")
                    return redirect('transaction_history')

                else:
                    form.add_error('amount', 'Insufficient funds')
            except UserProfile.DoesNotExist:
                form.add_error('recipient_account_number', 'Invalid account number')

    else:
        form = TransferForm()

    return render(request, 'transactions/transfer.html', {'form': form})

@login_required
def transaction_history(request):
    user_profile = UserProfile.objects.get(user=request.user)
    transactions = Transaction.objects.filter(user_profile=user_profile).order_by('-timestamp')  # or '-timestamp' if that's the field name
    balance = user_profile.balance  # Get the user's current balance
    return render(request, 'transactions/transaction_history.html', {'transactions': transactions, 'balance': balance})

@login_required
def transaction_success(request):
    return render(request, 'transactions/transaction_success.html')

@login_required
def logout_view(request):
    logout(request)
    messages.success(request, "Logged out successfully.")
    return redirect('login')

